# Nova Invest

A Firebase Hosting-ready premium investment and daily task application built with HTML, CSS, and vanilla JavaScript. It uses Firebase Authentication and Firebase Realtime Database only. Firebase Storage and Firestore are intentionally not used.

## Files

- `index.html` — user authentication and dashboard
- `admin.html` — admin console restricted to `admin@gmail.com`
- `style.css` — responsive premium glassmorphism design
- `script.js` — auth, realtime listeners, plans, tasks, wallet, referrals, profile, and history
- `admin.js` — admin management tools
- `firebase.js` — Firebase config and shared helpers
- `database.rules.json` — Realtime Database security rules

## Firebase setup

1. Create a Firebase project at https://console.firebase.google.com.
2. Enable Authentication → Sign-in method → Email/Password.
3. Create a Realtime Database and choose the correct region.
4. Copy the Web app configuration into the `firebaseConfig` object at the top of `firebase.js`. Keep `databaseURL` set to the exact URL shown by Firebase.
5. Deploy `database.rules.json` in Realtime Database → Rules.
6. Create the `admin@gmail.com` account in Authentication. The rules and UI use this exact email for admin access.
7. Optionally seed `plans`, `tasks`, `notices/main`, `slider/main`, and `payments` from the admin console.

## Hosting

From this `public` directory, run `firebase init hosting`, choose the existing project, use the current directory as the public directory, and deploy with `firebase deploy`. The same files are also available inside the Next preview shell at `/` and `/admin.html`.

## Data model

The app uses `users/{uid}`, `plans`, `tasks`, `deposits/{uid}`, `withdraws/{uid}`, `history/{uid}`, `notices`, `slider`, `settings`, `payments`, `referrals/{uid}`, and `statistics`. Screenshot fields are URL strings only; no image upload code exists.

## Security

Deploy the included rules before production. User records, wallet activity, requests, and history are scoped by Firebase Auth UID. Shared configuration is admin-write only. The client-side admin email check is paired with database rules, but you should still protect the admin account with a strong password and Firebase account security controls.

The blank configuration in the generated `firebase.js` is intentional. Replace it with your project configuration before expecting live auth or database persistence.
