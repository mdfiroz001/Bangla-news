const firebaseConfig = {
  apiKey: "",
  authDomain: "",
  databaseURL: "",
  projectId: "",
  storageBucket: "",
  messagingSenderId: "",
  appId: ""
};

const firebaseConfigured = Object.values(firebaseConfig).every(Boolean);
let app = null;
let auth = null;
let db = null;

if (firebaseConfigured) {
  app = firebase.initializeApp(firebaseConfig);
  auth = firebase.auth();
  db = firebase.database();
}

window.firebaseApp = { firebaseConfig, firebaseConfigured, app, auth, db };
window.firebaseReady = firebaseConfigured;

if (!firebaseConfigured) {
  window.dispatchEvent(new CustomEvent('firebase-setup-required'));
}

// Firebase Hosting can serve these static files directly. No Storage or Firestore APIs are used.

function dbRef(path) { return db ? db.ref(path) : null; }
window.dbRef = dbRef;

function safeKey(value) {
  return String(value || '').replace(/[.#$\[\]/]/g, '-');
}
window.safeKey = safeKey;

function formatMoney(value) {
  return new Intl.NumberFormat('en-BD', { style: 'currency', currency: 'BDT', maximumFractionDigits: 0 }).format(Number(value || 0));
}
window.formatMoney = formatMoney;

function formatDate(value) {
  return value ? new Date(value).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';
}
window.formatDate = formatDate;

function todayKey() { return new Date().toISOString().slice(0, 10); }
window.todayKey = todayKey;

function uidKey(uid) { return safeKey(uid); }
window.uidKey = uidKey;

function showToast(message, type = 'info') {
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.textContent = message;
  document.body.appendChild(toast);
  requestAnimationFrame(() => toast.classList.add('show'));
  setTimeout(() => { toast.classList.remove('show'); setTimeout(() => toast.remove(), 250); }, 3200);
}
window.showToast = showToast;

function setPath(path, value) { return dbRef(path)?.set(value); }
function updatePaths(values) { return db?.ref().update(values); }
window.setPath = setPath;
window.updatePaths = updatePaths;

function makeHistory(uid, type, amount, status = 'Completed', extra = {}) {
  return { uid, type, amount: Number(amount || 0), status, createdAt: Date.now(), ...extra };
}
window.makeHistory = makeHistory;

function seededPlans() {
  return {
    vip1: { name: 'VIP 1', price: 500, dailyTasks: 3, dailyProfit: 45, duration: 30, color: 'cyan' },
    vip2: { name: 'VIP 2', price: 1500, dailyTasks: 5, dailyProfit: 150, duration: 45, color: 'violet' },
    vip3: { name: 'VIP 3', price: 5000, dailyTasks: 8, dailyProfit: 600, duration: 60, color: 'pink' },
    vip4: { name: 'VIP 4', price: 12000, dailyTasks: 12, dailyProfit: 1800, duration: 90, color: 'gold' },
    vip5: { name: 'VIP 5', price: 30000, dailyTasks: 18, dailyProfit: 5200, duration: 120, color: 'blue' }
  };
}
window.seededPlans = seededPlans;

function seededTasks() {
  return {
    welcome: { title: 'Welcome to Nova Invest', description: 'Explore your dashboard and learn how to earn with Nova.', reward: 15, vipLevel: 1, imageUrl: 'https://images.unsplash.com/photo-1556761175-b413da4baf72?auto=format&fit=crop&w=900&q=80' },
    market: { title: 'Market intelligence briefing', description: 'Read today’s two-minute market briefing and unlock your reward.', reward: 35, vipLevel: 1, imageUrl: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?auto=format&fit=crop&w=900&q=80' },
    signal: { title: 'Premium signal review', description: 'Review the latest curated signal from our research desk.', reward: 80, vipLevel: 2, imageUrl: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=900&q=80' }
  };
}
window.seededTasks = seededTasks;
