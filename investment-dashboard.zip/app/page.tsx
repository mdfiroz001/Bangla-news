export default function Page() {
  return (
    <main className="min-h-screen bg-[#0c1027]">
      <iframe
        title="Nova Invest premium dashboard"
        src="/index.html"
        className="h-screen w-full border-0"
      />
    </main>
  )
}
